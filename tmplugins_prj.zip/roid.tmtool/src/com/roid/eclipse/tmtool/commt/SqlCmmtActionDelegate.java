package com.roid.eclipse.tmtool.commt;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.eclipse.core.filesystem.URIUtil;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IURIEditorInput;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.editors.text.ILocationProvider;

public class SqlCmmtActionDelegate implements IWorkbenchWindowActionDelegate {

	private ISelection selection;
	private IWorkbenchWindow window;

	public static final String JAVA_EDITOR_ID = "org.eclipse.jdt.ui.CompilationUnitEditor";

	@Override
	public void run(IAction action) {
		// this object is needed to render wizards, messages and so on
		Shell activeShell = window.getShell();
		// get selected items or text
		ISelection currentSelection = selection;
		// identify active GUI part
		String activePartId = getActivePartId();
		// java editor must be handled differently than view selection
		if (JAVA_EDITOR_ID.equals(activePartId)) {
			// get edited file
			IEditorInput input = getActiveEditor().getEditorInput();

			// currentSelection now contains text selection inside input file
			IFile file = getFileFromEditorInput(input);

			try (InputStream inputStream = file.getContents();) {

				List<String> lStr = IOUtils.readLines(inputStream, file.getCharset());

				inputStream.close();

				StringBuilder sb = new StringBuilder();
				
				String ptn = "^\\s*//+\\s*.*$";
				
				boolean isAlreadyCommt = false; 
				
				boolean isComment = false;
				boolean isModified = false;

				String lnTmp;
				
				for(String line : lStr) {

					if(line.contains("SQL_START")) {
						isComment = true;
					}
					
					if(isComment) {
						
						lnTmp = line;
						
						isAlreadyCommt = Pattern.matches(ptn, line);
						
						
						if(isAlreadyCommt) {
							line = line.replaceFirst("//+", "");
						}
						
						line = "//" + line;
						sb.append(line).append(IOUtils.LINE_SEPARATOR);
						
						if(!line.equals(lnTmp)) {
							isModified = true;
						}
						
					} else {
						sb.append(line).append(IOUtils.LINE_SEPARATOR);
					}
					
					if(line.contains("SQL_END")) {
						isComment = false;
					}
				}
				
				if(isModified) {
					byte[] bytes = sb.toString().getBytes(file.getCharset());
					InputStream source = new ByteArrayInputStream(bytes);
					file.setContents(source, IResource.NONE, null);
					source.close();
				}
				
				sb.setLength(0);
				sb = null;

			} catch (IOException | CoreException e) {
				e.printStackTrace();
			}

		} else {

			// currentSelection now contains all classes inside
			// ... collect all selected classes ...

		}
	}

	public static IFile getFileFromEditorInput(IEditorInput input) {
		if (input == null)
			return null;

		if (input instanceof IFileEditorInput)
			return ((IFileEditorInput) input).getFile();

		IPath path = getPathFromEditorInput(input);
		if (path == null)
			return null;

		return ResourcesPlugin.getWorkspace().getRoot().getFile(path);
	}

	public static IPath getPathFromEditorInput(IEditorInput input) {
		if (input instanceof ILocationProvider)
			return ((ILocationProvider) input).getPath(input);

		if (input instanceof IURIEditorInput) {
			URI uri = ((IURIEditorInput) input).getURI();
			if (uri != null) {
				IPath path = URIUtil.toPath(uri);
				if (path != null)
					return path;
			}
		}

		return null;
	}

	private IEditorPart getActiveEditor() {
		return window.getActivePage().getActiveEditor();
	}

	private String getActivePartId() {
		return window.getPartService().getActivePartReference().getId();
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

	@Override
	public void dispose() {
	}

	@Override
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

}
